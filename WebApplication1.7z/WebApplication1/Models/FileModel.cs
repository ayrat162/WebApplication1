﻿namespace WebApplication1.Models
{
    public class FileModel
    {
        public string[] FileNames { get; set; }
    }
}